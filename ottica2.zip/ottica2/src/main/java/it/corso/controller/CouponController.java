package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.model.Occhiale;
import it.corso.service.OcchialeService;

@Controller
@RequestMapping(path = "/coupon")
public class CouponController {

	@Autowired
	private OcchialeService occhialeService;
	
	@GetMapping
	public String getPage(Model model, @RequestParam(name = "id", required = false) Integer id) {
		if(id == null) {
			return "redirect:/index";
		}
		String orario = occhialeService.orarioCoupon();
		String codice = occhialeService.codiceSconto();
		Occhiale occhiale = occhialeService.getOcchialeById(id);
		double prezzoFinale = occhialeService.applicaSconto(occhiale.getPrezzo());
		model.addAttribute("codice", codice);
		model.addAttribute("marca", occhiale.getMarca());
		model.addAttribute("prezzo", occhiale.getPrezzo());
		model.addAttribute("modello", occhiale.getModello());
		model.addAttribute("tipologia", occhiale.getTipologia());
		model.addAttribute("prezzoFinale", prezzoFinale);
		model.addAttribute("orario", orario);
		return "coupon";
	}
}
