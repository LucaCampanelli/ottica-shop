package it.corso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import it.corso.service.OcchialeService;

@Controller
@RequestMapping(path = "/catalogo")
public class CatalogoController {
	
	@Autowired
	private OcchialeService occhialeService;

	//http://localhost:8080/ottica2/catalogo?materiale=
	
	@GetMapping
	public String getPage(Model model, @RequestParam(name = "materiale", required = false) String materiale, @RequestParam(name = "marca", required = false) String marca, @RequestParam(name = "genere", required = false) String genere, @RequestParam(name = "colore", required = false) String colore, @RequestParam(name = "tipologia", required = false) String tipologia) {
		
		String uno = "Tutti gli occhiali";
		String due = "Tutti gli occhiali con la montatura in " + materiale;
		String tre = "Tutti gli occhiali di " + marca;
		String quattro = "Tutti gli occhiali per " + genere;
		String cinque = "Tutti gli occhiali con la montatura di colore " + colore;
		String sei = "Tutti gli occhiali " + tipologia;
		
		if(materiale == "") {
			model.addAttribute("occhiali", occhialeService.getOcchiali());
			model.addAttribute("stringa", uno);
			return "catalogo";
		}
		else if(materiale != null) {
			model.addAttribute("occhiali", occhialeService.getOcchialiMateriale(materiale));
			model.addAttribute("stringa", due);
			return "catalogo";
		}
		
		if(marca == "") {
			model.addAttribute("occhiali", occhialeService.getOcchiali());
			model.addAttribute("stringa", uno);
			return "catalogo";
		}
		else if(marca != null) {
			model.addAttribute("occhiali", occhialeService.getOcchialiMarca(marca));
			model.addAttribute("stringa", tre);
			return "catalogo";
		}
		
		if(genere == "") {
			model.addAttribute("occhiali", occhialeService.getOcchiali());
			model.addAttribute("stringa", uno);
			return "catalogo";
		}
		else if(genere != null) {
			model.addAttribute("occhiali", occhialeService.getOcchialiGenere(genere));
			model.addAttribute("stringa", quattro);
			return "catalogo";
		}
		
		if(colore == "") {
			model.addAttribute("occhiali", occhialeService.getOcchiali());
			model.addAttribute("stringa", uno);
			return "catalogo";
		}
		else if(colore != null) {
			model.addAttribute("occhiali", occhialeService.getOcchialiColore(colore));
			model.addAttribute("stringa", cinque);
			return "catalogo";
		}
		
		if(tipologia == "") {
			model.addAttribute("occhiali", occhialeService.getOcchiali());
			model.addAttribute("stringa", uno);
			return "catalogo";
		}
		else if(tipologia != null) {
			model.addAttribute("occhiali", occhialeService.getOcchialiTipologia(tipologia));
			model.addAttribute("stringa", sei);
			return "catalogo";
		}
		
			
		model.addAttribute("occhiali", occhialeService.getOcchiali());
		model.addAttribute("stringa", uno);
			
		
		return "catalogo";
	}
	
	
	
}
